def bold(string: str):
    return '[b]' + string + '[/b]'


def italic(string: str):
    return '[i]' + string + '[/i]'


def underline(string: str):
    return '[u]' + string + '[/u]'